package co.vinni.kafka.SBConsumidor.listener;

import co.vinni.kafka.SBConsumidor.UI.NoticiaConsumerUI;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class KafkaConsumerListener {

    private final NoticiaConsumerUI ui;
    private final ObjectMapper mapper = new ObjectMapper();

    public KafkaConsumerListener(NoticiaConsumerUI ui) {
        this.ui = ui;
    }

    @KafkaListener(topics = "noticias-ropa", groupId = "grupo-noticias")
    public void escuchar(String mensaje) {
        try {
            // Parsear el JSON que viene del productor
            JsonNode json = mapper.readTree(mensaje);
            String titulo = json.get("titulo").asText();
            String contenido = json.get("contenido").asText();

            // Mostrar en consola
            System.out.println("📥 Noticia recibida:");
            System.out.println("Título: " + titulo);
            System.out.println("Contenido: " + contenido);

            // Mostrar en la interfaz gráfica
            ui.agregarNoticia(titulo, contenido);

        } catch (Exception e) {
            System.err.println("❌ Error al procesar mensaje: " + mensaje);
            e.printStackTrace();
        }
    }
}



