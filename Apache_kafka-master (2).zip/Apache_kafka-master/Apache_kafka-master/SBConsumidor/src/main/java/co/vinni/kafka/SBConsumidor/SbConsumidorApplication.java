package co.vinni.kafka.SBConsumidor;

import co.vinni.kafka.SBConsumidor.UI.NoticiaConsumerUI;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import javax.swing.*;

@SpringBootApplication
public class SbConsumidorApplication {
    public static void main(String[] args) {
        ApplicationContext context = SpringApplication.run(SbConsumidorApplication.class, args);

        // Lanzar la UI explícitamente
        SwingUtilities.invokeLater(() -> {
            NoticiaConsumerUI ui = context.getBean(NoticiaConsumerUI.class);
            ui.setVisible(true);
        });
    }
}



