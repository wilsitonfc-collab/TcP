package co.vinni.kafka.SBConsumidor.UI;

import org.springframework.stereotype.Component;

import javax.swing.*;
import java.awt.*;

@Component // 👈 Esto la convierte en Bean de Spring
public class NoticiaConsumerUI extends JFrame {

    private final JTextArea feedArea;

    public NoticiaConsumerUI() {
        setTitle("Feed de Noticias Deportivas");
        setSize(500, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        feedArea = new JTextArea();
        feedArea.setEditable(false);
        feedArea.setFont(new Font("Arial", Font.PLAIN, 14));

        add(new JScrollPane(feedArea), BorderLayout.CENTER);
    }

    public void agregarNoticia(String titulo, String contenido) {
        SwingUtilities.invokeLater(() -> {
            feedArea.append("📰 " + titulo + "\n");
            feedArea.append(contenido + "\n");
            feedArea.append("------------------------------------\n");
        });
    }
}

