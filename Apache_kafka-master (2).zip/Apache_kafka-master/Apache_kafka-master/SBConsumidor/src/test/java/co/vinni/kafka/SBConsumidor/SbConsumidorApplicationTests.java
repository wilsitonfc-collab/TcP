package co.vinni.kafka.SBConsumidor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbConsumidorApplicationTests {

	@Test
	void contextLoads() {
	}

}
