package co.vinni.kafka.SBProveedor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbProveedorApplicationTests {

	@Test
	void contextLoads() {
	}

}
