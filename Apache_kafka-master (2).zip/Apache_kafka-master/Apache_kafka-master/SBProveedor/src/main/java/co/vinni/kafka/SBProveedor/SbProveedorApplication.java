package co.vinni.kafka.SBProveedor;

import co.vinni.kafka.SBProveedor.ui.Noticiaui;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import javax.swing.*;

@SpringBootApplication
public class SbProveedorApplication {
    public static void main(String[] args) {
        ApplicationContext context = SpringApplication.run(SbProveedorApplication.class, args);

        SwingUtilities.invokeLater(() -> {
            Noticiaui ui = context.getBean(Noticiaui.class);
            ui.setVisible(true);
        });
    }
}


