package co.vinni.kafka.SBProveedor.Noticia;

public class Noticia {
    private String titulo;
    private String contenido;

    // Constructor vacío (requerido por Spring)
    public Noticia() {}

    // Constructor con parámetros
    public Noticia(String titulo, String contenido) {
        this.titulo = titulo;
        this.contenido = contenido;
    }

    // Getters y Setters
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }
}
