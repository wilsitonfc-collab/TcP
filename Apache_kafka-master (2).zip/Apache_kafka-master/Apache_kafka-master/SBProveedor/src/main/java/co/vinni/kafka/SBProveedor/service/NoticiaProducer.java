package co.vinni.kafka.SBProveedor.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class NoticiaProducer {

    private final KafkaTemplate<String, String> kafkaTemplate;

    @Value("${app.kafka.topic:noticias-ropa}")
    private String topic;

    public NoticiaProducer(KafkaTemplate<String, String> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    // Firma que el UI espera: titulo + contenido
    public void enviarNoticia(String titulo, String contenido) {
        String payload = buildJson(titulo, contenido);
        kafkaTemplate.send(topic, payload);
        System.out.println("📤 Noticia enviada: " + payload);
    }

    // Helper simple para escapar caracteres que rompen JSON
    private String escapeJson(String s) {
        if (s == null) return "";
        return s
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r");
    }

    private String buildJson(String titulo, String contenido) {
        return "{\"titulo\":\"" + escapeJson(titulo) + "\",\"contenido\":\"" + escapeJson(contenido) + "\"}";
    }
}
