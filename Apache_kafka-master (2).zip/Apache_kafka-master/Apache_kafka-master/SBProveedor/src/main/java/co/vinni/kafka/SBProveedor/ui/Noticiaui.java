package co.vinni.kafka.SBProveedor.ui;

import co.vinni.kafka.SBProveedor.service.NoticiaProducer;
import org.springframework.stereotype.Component;

import javax.swing.*;
import java.awt.*;

@Component
public class Noticiaui extends JFrame {

    public Noticiaui(NoticiaProducer noticiaProducer) {
        setTitle("Productor de Noticias Deportivas");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(5, 1));

        JTextField tituloField = new JTextField();
        JTextArea contenidoArea = new JTextArea();
        JButton enviarBtn = new JButton("Enviar Noticia");

        add(new JLabel("Título:"));
        add(tituloField);
        add(new JLabel("Contenido:"));
        add(new JScrollPane(contenidoArea));
        add(enviarBtn);

        enviarBtn.addActionListener(e -> {
            String titulo = tituloField.getText();
            String contenido = contenidoArea.getText();

            if (!titulo.isEmpty() && !contenido.isEmpty()) {
                noticiaProducer.enviarNoticia(titulo, contenido);
                JOptionPane.showMessageDialog(this, "Noticia enviada ✅");
                tituloField.setText("");
                contenidoArea.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "Debes llenar ambos campos ⚠️");
            }
        });
    }
}
