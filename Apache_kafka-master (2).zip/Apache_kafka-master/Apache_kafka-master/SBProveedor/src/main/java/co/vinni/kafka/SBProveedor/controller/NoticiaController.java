package co.vinni.kafka.SBProveedor.controller;

import co.vinni.kafka.SBProveedor.service.NoticiaProducer;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/noticias")
public class NoticiaController {

    private final NoticiaProducer noticiaProducer;

    public NoticiaController(NoticiaProducer noticiaProducer) {
        this.noticiaProducer = noticiaProducer;
    }

    // Endpoint que recibe un JSON con titulo y contenido
    @PostMapping("/enviar")
    public String enviarNoticia(@RequestBody NoticiaRequest noticia) {
        noticiaProducer.enviarNoticia(noticia.getTitulo(), noticia.getContenido());
        return "✅ Noticia enviada: " + noticia.getTitulo();
    }

    // DTO interno (para no crear otra clase aparte si no quieres)
    public static class NoticiaRequest {
        private String titulo;
        private String contenido;

        public String getTitulo() {
            return titulo;
        }
        public void setTitulo(String titulo) {
            this.titulo = titulo;
        }
        public String getContenido() {
            return contenido;
        }
        public void setContenido(String contenido) {
            this.contenido = contenido;
        }
    }
}

