package org.vinni.cliente.gui;


import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.Properties;


public class PrincipalCli extends JFrame {
    private Socket socket;
    private DataInputStream in;
    private DataOutputStream out;
    private String nombreCliente;


    private JTextPane mensajesPane;
    private JTextField mensajeTxt;


    // Configuración desde archivo
    private int reintentos = 5;
    private int esperaMs = 3000;


    public PrincipalCli() {
        cargarConfiguracion();
        initComponents();


        nombreCliente = JOptionPane.showInputDialog(this, "Ingrese su nombre de cliente:");
        if (nombreCliente == null || nombreCliente.trim().isEmpty()) {
            nombreCliente = "Cliente-" + (int) (Math.random() * 1000);
        }
    }


    private void initComponents() {
        setTitle("Cliente Chat");
        setLayout(null);


        mensajesPane = new JTextPane();
        mensajesPane.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(mensajesPane);
        scrollPane.setBounds(20, 20, 450, 200);
        add(scrollPane);


        mensajeTxt = new JTextField();
        mensajeTxt.setBounds(20, 240, 300, 30);
        add(mensajeTxt);


        JButton btEnviar = new JButton("Enviar");
        btEnviar.setBounds(330, 240, 120, 30);
        btEnviar.addActionListener(e -> enviarMensaje());
        add(btEnviar);


        JButton btArchivo = new JButton("Enviar Archivo");
        btArchivo.setBounds(20, 280, 150, 30);
        btArchivo.addActionListener(e -> enviarArchivo());
        add(btArchivo);


        JButton btConectar = new JButton("Conectar");
        btConectar.setBounds(200, 280, 120, 30);
        btConectar.addActionListener(e -> conectarConReintentos());
        add(btConectar);


        setSize(500, 370);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }


    private void cargarConfiguracion() {
        try (InputStream input = getClass().getClassLoader().getResourceAsStream("config.properties")) {
            if (input != null) {
                Properties prop = new Properties();
                prop.load(input);
                reintentos = Integer.parseInt(prop.getProperty("reintentos", "5"));
                esperaMs = Integer.parseInt(prop.getProperty("espera_ms", "3000"));
            }
        } catch (IOException ex) {
            appendMensaje("No se pudo leer config.properties, usando valores por defecto.", Color.GRAY);
        }
    }


    // ================= CONEXIÓN MANUAL CON REINTENTOS ====================
    private void conectarConReintentos() {
        new Thread(() -> {
            int intento = 0;
            boolean conectado = false;


            String ip = JOptionPane.showInputDialog(this, "IP servidor:", "127.0.0.1");
            int puerto = Integer.parseInt(JOptionPane.showInputDialog(this, "Puerto:", "12345"));


            while (intento < reintentos && !conectado) {
                try {
                    socket = new Socket(ip, puerto);
                    socket.setSoTimeout(3000); // timeout para detectar inactividad


                    in = new DataInputStream(socket.getInputStream());
                    out = new DataOutputStream(socket.getOutputStream());


                    out.writeUTF(nombreCliente);
                    new Thread(this::escuchar).start();
                    appendMensaje("✅ Conectado al servidor en intento " + (intento + 1), Color.BLUE);
                    conectado = true;
                } catch (Exception e) {
                    intento++;
                    appendMensaje("❌ Falló intento " + intento + " de " + reintentos, Color.RED);
                    try { Thread.sleep(esperaMs); } catch (InterruptedException ignored) {}
                }
            }


            if (!conectado) {
                appendMensaje("⛔ No se pudo conectar al servidor después de " + reintentos + " intentos.", Color.RED);
            }
        }).start();
    }


    // ================= ESCUCHA Y DETECCIÓN DE CAÍDA ====================
    private void escuchar() {
        try {
            while (true) {
                try {
                    String header = in.readUTF(); // puede lanzar SocketTimeoutException


                    if (header.startsWith("MSG|")) {
                        String[] partes = header.split("\\|", 3);
                        appendMensaje(partes[1] + ": " + partes[2], Color.BLACK);


                    } else if (header.startsWith("FILE|")) {
                        String[] partes = header.split("\\|", 4);
                        String nombreArchivo = partes[2];
                        long tam = Long.parseLong(partes[3]);


                        byte[] datos = new byte[(int) tam];
                        int leido = 0;
                        while (leido < tam) {
                            int n = in.read(datos, leido, (int) (tam - leido));
                            if (n == -1) throw new IOException("Fin de stream inesperado");
                            leido += n;
                        }


                        SwingUtilities.invokeLater(() -> {
                            JFileChooser chooser = new JFileChooser();
                            chooser.setSelectedFile(new File(nombreArchivo));
                            int opcion = chooser.showSaveDialog(this);
                            if (opcion == JFileChooser.APPROVE_OPTION) {
                                File destino = chooser.getSelectedFile();
                                try (FileOutputStream fos = new FileOutputStream(destino)) {
                                    fos.write(datos);
                                    appendMensaje("📂 Archivo guardado en: " + destino.getAbsolutePath(), Color.BLUE);
                                } catch (IOException ex) {
                                    appendMensaje("Error guardando archivo: " + ex.getMessage(), Color.RED);
                                }
                            } else {
                                appendMensaje("Archivo rechazado: " + nombreArchivo, Color.GRAY);
                            }
                        });
                    }
                } catch (SocketTimeoutException e) {
                    // Timeout sin datos, ignoramos para seguir escuchando
                    continue;
                }
            }
        } catch (IOException e) {
            appendMensaje("⚠ Conexión perdida con el servidor. Intentando reconectar...", Color.RED);
            reconectarConReintentos();
        }
    }


    // === Solo te paso modificado ===
// Método reconectarConReintentos


    private void reconectarConReintentos() {
        new Thread(() -> {
            int intento = 0;
            boolean conectado = false;
            String ip = socket.getInetAddress().getHostAddress();
            int puerto = socket.getPort();


            while (intento < reintentos && !conectado) {
                try {
                    socket = new Socket(ip, puerto);
                    socket.setSoTimeout(3000);


                    in = new DataInputStream(socket.getInputStream());
                    out = new DataOutputStream(socket.getOutputStream());


                    out.writeUTF(nombreCliente);
                    new Thread(this::escuchar).start();
                    appendMensaje("✅ Reconectado al servidor en intento " + (intento + 1), Color.BLUE);
                    conectado = true;
                } catch (Exception ex) {
                    intento++;
                    appendMensaje("❌ Falló reconexión " + intento + " de " + reintentos, Color.RED);
                    try { Thread.sleep(esperaMs); } catch (InterruptedException ignored) {}
                }
            }


            // 🔹 Si después de los reintentos no conecta, esperar pasivamente al monitor
            if (!conectado) {
                appendMensaje("⏸ Esperando que el monitor reactive el servidor...", Color.ORANGE);


                while (!conectado) {
                    try {
                        socket = new Socket(ip, puerto);
                        socket.setSoTimeout(3000);


                        in = new DataInputStream(socket.getInputStream());
                        out = new DataOutputStream(socket.getOutputStream());


                        out.writeUTF(nombreCliente);
                        new Thread(this::escuchar).start();
                        appendMensaje("🔄 Conexión restablecida por el monitor.", Color.BLUE);
                        conectado = true;
                    } catch (Exception ex) {
                        try { Thread.sleep(esperaMs); } catch (InterruptedException ignored) {}
                    }
                }
            }
        }).start();
    }




    // ================= ENVÍO DE MENSAJES ====================
    private void enviarMensaje() {
        try {
            String destinatario = JOptionPane.showInputDialog(this, "Enviar a:", "Todos");
            if (destinatario == null || destinatario.isEmpty()) destinatario = "Todos";


            String mensaje = mensajeTxt.getText();
            if (!mensaje.isEmpty()) {
                out.writeUTF("MSG|" + destinatario + "|" + mensaje);
                mensajeTxt.setText("");
            }
        } catch (IOException e) {
            appendMensaje("Error enviando: " + e.getMessage(), Color.RED);
        }
    }


    // ================= ENVÍO DE ARCHIVOS ====================
    private void enviarArchivo() {
        try {
            String destinatario = JOptionPane.showInputDialog(this, "Enviar a:", "Todos");
            if (destinatario == null || destinatario.isEmpty()) destinatario = "Todos";


            JFileChooser chooser = new JFileChooser();
            if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
                File archivo = chooser.getSelectedFile();
                FileInputStream fis = new FileInputStream(archivo);


                out.writeUTF("FILE|" + destinatario + "|" + archivo.getName() + "|" + archivo.length());


                byte[] buffer = new byte[4096];
                int n;
                while ((n = fis.read(buffer)) != -1) {
                    out.write(buffer, 0, n);
                }
                out.flush();
                fis.close();


                appendMensaje("📤 Archivo enviado: " + archivo.getName(), Color.MAGENTA);
            }
        } catch (IOException e) {
            appendMensaje("Error enviando archivo: " + e.getMessage(), Color.RED);
        }
    }


    // ================= APPEND MENSAJES ====================
    private void appendMensaje(String mensaje, Color color) {
        StyledDocument doc = mensajesPane.getStyledDocument();
        Style style = mensajesPane.addStyle("Style", null);
        StyleConstants.setForeground(style, color);
        try {
            doc.insertString(doc.getLength(), mensaje + "\n", style);
            mensajesPane.setCaretPosition(doc.getLength());
        } catch (BadLocationException e) {
            e.printStackTrace();
        }
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new PrincipalCli().setVisible(true));
    }
}
