package org.vinni.monitor;


import org.vinni.servidor.gui.PrincipalSrv;


import javax.swing.*;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Properties;
import java.io.InputStream;


public class Monitor extends JFrame {
    private JTextArea logArea;
    private JButton iniciarBtn;


    private String host = "127.0.0.1";
    private int puerto = 12345;
    private int intervalo = 3000;
    private int reinicioIntento = 3;


    private boolean monitoreando = false;
    private PrincipalSrv servidorActivo;
    private boolean ultimoEstadoActivo = false; // para evitar bucles de logs


    public Monitor() {
        cargarConfig();
        initComponents();
    }


    private void initComponents() {
        setTitle("Monitor de Servidor");
        setSize(500, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);


        JLabel titulo = new JLabel("MONITOR DE SERVIDOR");
        titulo.setBounds(20, 10, 400, 25);
        add(titulo);


        logArea = new JTextArea();
        logArea.setEditable(false);
        JScrollPane scroll = new JScrollPane(logArea);
        scroll.setBounds(20, 50, 440, 150);
        add(scroll);


        iniciarBtn = new JButton("Iniciar Monitor");
        iniciarBtn.setBounds(150, 220, 180, 30);
        iniciarBtn.addActionListener(e -> iniciarMonitor());
        add(iniciarBtn);


        setLocationRelativeTo(null);
    }


    private void cargarConfig() {
        try (InputStream input = getClass().getClassLoader().getResourceAsStream("config.properties")) {
            if (input != null) {
                Properties prop = new Properties();
                prop.load(input);
                host = prop.getProperty("host", "127.0.0.1");
                puerto = Integer.parseInt(prop.getProperty("puerto", "12345"));
                intervalo = Integer.parseInt(prop.getProperty("intervalo_monitor", "3000"));
                reinicioIntento = Integer.parseInt(prop.getProperty("reinicio_intento", "3"));
            }
        } catch (IOException e) {
            log("[ERROR] No se pudo leer config.properties, usando valores por defecto.");
        }
    }


    private void iniciarMonitor() {
        if (monitoreando) {
            log("[MONITOR] Ya está en ejecución.");
            return;
        }


        monitoreando = true;
        log("[MONITOR] Iniciado. Monitoreando servidor en " + host + ":" + puerto);


        new Thread(() -> {
            int intentosFallidos = 0;


            while (monitoreando) {
                boolean activo = estaServidorActivo();


                if (!activo) {
                    intentosFallidos++;
                    if (ultimoEstadoActivo) {
                        log("[MONITOR] Servidor caído. Intento " + intentosFallidos);
                    }


                    if (intentosFallidos == reinicioIntento) {
                        log("[MONITOR] Reiniciando servidor en intento " + intentosFallidos + "...");
                        SwingUtilities.invokeLater(() -> {
                            if (servidorActivo == null) {
                                servidorActivo = new PrincipalSrv();
                                servidorActivo.setVisible(true);
                                log("[MONITOR] Servidor reiniciado correctamente.");
                            } else {
                                log("[MONITOR] Ya existe un servidor en ejecución, no se reinicia otro.");
                            }
                        });
                        intentosFallidos = 0;
                    }
                } else {
                    if (!ultimoEstadoActivo) {
                        log("[MONITOR] Servidor activo.");
                    }
                    intentosFallidos = 0;
                }


                ultimoEstadoActivo = activo;


                try {
                    Thread.sleep(intervalo);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        }).start();
    }


    private boolean estaServidorActivo() {
        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress(host, puerto), 2000);
            return true;
        } catch (IOException e) {
            return false;
        }
    }


    private void log(String mensaje) {
        SwingUtilities.invokeLater(() -> logArea.append(mensaje + "\n"));
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Monitor().setVisible(true));
    }
}

