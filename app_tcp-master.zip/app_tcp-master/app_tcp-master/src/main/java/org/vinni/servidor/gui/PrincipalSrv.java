package org.vinni.servidor.gui;


import javax.swing.*;
import java.io.*;
import java.net.*;
import java.util.concurrent.*;
import java.util.*;
import java.util.Properties;


public class PrincipalSrv extends JFrame {
    private int PORT = 12345;
    private ServerSocket serverSocket;
    private JTextArea mensajesTxt;
    private ExecutorService pool;
    private final Map<String, DataOutputStream> clientes = new ConcurrentHashMap<>();


    // 🔹 Lista de conexiones activas
    private final List<Socket> conexionesActivas = Collections.synchronizedList(new ArrayList<>());


    // Botones
    private JButton bIniciar, bBajar;


    public PrincipalSrv() {
        cargarConfiguracion();
        initComponents();
    }


    private void initComponents() {
        this.setTitle("Servidor TCP - Multiusuario");
        bIniciar = new JButton("INICIAR SERVIDOR");
        bBajar = new JButton("BAJAR SERVIDOR");
        JLabel jLabel1 = new JLabel("SERVIDOR TCP : MULTI CLIENTES");
        mensajesTxt = new JTextArea();
        JScrollPane jScrollPane1 = new JScrollPane(mensajesTxt);


        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);


        bIniciar.setBounds(50, 90, 180, 40);
        bBajar.setBounds(250, 90, 180, 40);
        jLabel1.setBounds(50, 10, 400, 17);
        jScrollPane1.setBounds(20, 160, 450, 120);


        // 🔹 Arranca sin reintentos, directo
        bIniciar.addActionListener(evt -> {
            try {
                iniciarServidor();
            } catch (IOException e) {
                mensajesTxt.append("[ERROR] No se pudo iniciar el servidor: " + e.getMessage() + "\n");
            }
        });


        bBajar.addActionListener(evt -> bajarServidor());


        add(bIniciar);
        add(bBajar);
        add(jLabel1);
        add(jScrollPane1);


        setSize(500, 350);
        setLocationRelativeTo(null);
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new PrincipalSrv().setVisible(true));
    }


    // 🔹 Cargar parámetros desde config.properties
    private void cargarConfiguracion() {
        try (InputStream input = getClass().getClassLoader().getResourceAsStream("config.properties")) {
            if (input != null) {
                Properties prop = new Properties();
                prop.load(input);
                PORT = Integer.parseInt(prop.getProperty("puerto", "12345"));
            }
        } catch (IOException ex) {
            System.out.println("No se pudo leer config.properties, usando valores por defecto.");
        }
    }


    // 🔹 Inicia el servidor (un solo intento, sin bucles)
    public void iniciarServidor() throws IOException {
        if (serverSocket != null && !serverSocket.isClosed()) {
            mensajesTxt.append("[SERVIDOR] Ya está en ejecución.\n");
            return;
        }


        serverSocket = new ServerSocket(PORT);
        pool = Executors.newFixedThreadPool(10);


        mensajesTxt.append("✅ Conexión restablecida. Puerto: " + PORT + "\n");


        new Thread(() -> {
            try {
                while (!serverSocket.isClosed()) {
                    Socket clientSocket = serverSocket.accept();
                    conexionesActivas.add(clientSocket);
                    pool.execute(new ClientHandler(clientSocket));
                }
            } catch (IOException ex) {
                mensajesTxt.append("[SERVIDOR] Se detuvo la aceptación de conexiones.\n");
            }
        }).start();
    }


    // 🔹 Bajar servidor (cerrar socket y clientes activos)
    private void bajarServidor() {
        try {
            if (serverSocket != null && !serverSocket.isClosed()) {
                serverSocket.close();
            }


            synchronized (conexionesActivas) {
                for (Socket c : conexionesActivas) {
                    try {
                        c.close();
                    } catch (IOException ignored) {}
                }
                conexionesActivas.clear();
            }


            mensajesTxt.append("[SERVIDOR] Servidor detenido manualmente.\n");
        } catch (IOException e) {
            mensajesTxt.append("[ERROR] Al detener el servidor: " + e.getMessage() + "\n");
        }
    }


    // ================== CLIENT HANDLER ===================
    private class ClientHandler implements Runnable {
        private Socket socket;
        private DataInputStream in;
        private DataOutputStream out;
        private String nombreCliente;


        public ClientHandler(Socket socket) {
            this.socket = socket;
        }


        @Override
        public void run() {
            try {
                in = new DataInputStream(socket.getInputStream());
                out = new DataOutputStream(socket.getOutputStream());


                nombreCliente = in.readUTF(); // primer mensaje es el nombre
                clientes.put(nombreCliente, out);
                mensajesTxt.append("[SERVIDOR] " + nombreCliente + " se ha conectado.\n");


                while (true) {
                    String header = in.readUTF(); // encabezado textual


                    if (header.startsWith("MSG|")) {
                        String[] partes = header.split("\\|", 3);
                        String destinatario = partes[1];
                        String mensaje = partes[2];


                        if ("Todos".equalsIgnoreCase(destinatario)) {
                            // enviar a todos
                            for (Map.Entry<String, DataOutputStream> entry : clientes.entrySet()) {
                                entry.getValue().writeUTF("MSG|" + nombreCliente + "|" + mensaje);
                            }
                        } else {
                            DataOutputStream destOut = clientes.get(destinatario);
                            if (destOut != null) {
                                destOut.writeUTF("MSG|" + nombreCliente + "|" + mensaje);
                            }
                        }


                        mensajesTxt.append("[MSG] " + nombreCliente + " → " + destinatario + ": " + mensaje + "\n");


                    } else if (header.startsWith("FILE|")) {
                        String[] partes = header.split("\\|", 4);
                        String destinatario = partes[1];
                        String nombreArchivo = partes[2];
                        long tam = Long.parseLong(partes[3]);


                        byte[] buffer = new byte[4096];
                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                        long leido = 0;
                        while (leido < tam) {
                            int n = in.read(buffer, 0, (int) Math.min(buffer.length, tam - leido));
                            if (n == -1) throw new IOException("Cliente desconectado durante transferencia");
                            baos.write(buffer, 0, n);
                            leido += n;
                        }
                        byte[] datosArchivo = baos.toByteArray();


                        if ("Todos".equalsIgnoreCase(destinatario)) {
                            for (Map.Entry<String, DataOutputStream> entry : clientes.entrySet()) {
                                entry.getValue().writeUTF("FILE|" + nombreCliente + "|" + nombreArchivo + "|" + tam);
                                entry.getValue().write(datosArchivo);
                                entry.getValue().flush();
                            }
                        } else {
                            DataOutputStream destOut = clientes.get(destinatario);
                            if (destOut != null) {
                                destOut.writeUTF("FILE|" + nombreCliente + "|" + nombreArchivo + "|" + tam);
                                destOut.write(datosArchivo);
                                destOut.flush();
                            }
                        }


                        mensajesTxt.append("[FILE] " + nombreCliente + " → " + destinatario + ": " + nombreArchivo + " (" + tam + " bytes)\n");
                    }
                }
            } catch (IOException e) {
                if (nombreCliente != null) {
                    mensajesTxt.append("[SERVIDOR] Cliente desconectado: " + nombreCliente + "\n");
                }
            } finally {
                try {
                    clientes.remove(nombreCliente);
                    conexionesActivas.remove(socket);
                    socket.close();
                } catch (IOException e) {}
            }
        }
    }
}
